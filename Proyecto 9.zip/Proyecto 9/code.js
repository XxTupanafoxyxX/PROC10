var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","c4e310e0-8174-4127-a46e-0cbcc94b488b","87119499-1a86-4422-bd6f-00a24353bc19","bc8c494a-a266-41f2-918d-709f7da74aaa","2364678a-5142-4cb4-bb21-640119699a93","45e5aaf1-242c-4921-bfd0-eeb0dd67a9e6","44941cfe-80e0-45dd-b20e-10df50e98cf7"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"0ZIAbGPpYpwrC5OFUuxRtpitBcYu21I7","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"FxjSLHquDyOVnIAgwNLEE1rl_GhrKGQO","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"r9y2gNiXrB1VFVjjpRMx_T9mbg6SPH5v","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"87119499-1a86-4422-bd6f-00a24353bc19":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/Mz9t_vVZ_K7DL7e61UbY1ivgFlG0hkqh/category_fantasy/alien_04.png","frameSize":{"x":347,"y":392},"frameCount":1,"looping":true,"frameDelay":2,"version":"Mz9t_vVZ_K7DL7e61UbY1ivgFlG0hkqh","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":347,"y":392},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Mz9t_vVZ_K7DL7e61UbY1ivgFlG0hkqh/category_fantasy/alien_04.png"},"bc8c494a-a266-41f2-918d-709f7da74aaa":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/mj2ti2iXM44mDQz.rcLgzlE_41.J15kR/category_fantasy/alien_03.png","frameSize":{"x":389,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"mj2ti2iXM44mDQz.rcLgzlE_41.J15kR","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":389,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/mj2ti2iXM44mDQz.rcLgzlE_41.J15kR/category_fantasy/alien_03.png"},"2364678a-5142-4cb4-bb21-640119699a93":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/nVBK1OnWogFitvGAbWs4ey1tFRWCwaVl/category_fantasy/alien_01.png","frameSize":{"x":365,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"nVBK1OnWogFitvGAbWs4ey1tFRWCwaVl","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":365,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nVBK1OnWogFitvGAbWs4ey1tFRWCwaVl/category_fantasy/alien_01.png"},"45e5aaf1-242c-4921-bfd0-eeb0dd67a9e6":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/IZ.8ZbQRR_RBvwLhNLFZTJZ2m699aT8b/category_retro/retroaliens_04.png","frameSize":{"x":400,"y":356},"frameCount":1,"looping":true,"frameDelay":2,"version":"IZ.8ZbQRR_RBvwLhNLFZTJZ2m699aT8b","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":356},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IZ.8ZbQRR_RBvwLhNLFZTJZ2m699aT8b/category_retro/retroaliens_04.png"},"44941cfe-80e0-45dd-b20e-10df50e98cf7":{"name":"espacio","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var espacio = createSprite(200,200);
 espacio.setAnimation("espacio")
var hero = createSprite(200,345,200,345)
hero.shapeColor="red"

var enemy1 = createSprite(200,250,10,10)
enemy1.shapeColor="red"

var enemy2 = createSprite(200,150,10,10)
enemy2.shapeColor="red"

var enemy3 = createSprite(200,50,10,10)
enemy3.shapeColor="red"

var net = createSprite(200,5,200,20)
net.shapeColor="red"

var goal =0;
var death = 0

hero.setAnimation("hero1");
hero.scale=.2;
enemy1.setAnimation("enemy");
enemy1.scale=.1;
enemy2.setAnimation("enemy2");
enemy2.scale=.1;
enemy3.setAnimation("enemy3");
enemy3.scale=.1;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
  


createEdgeSprites()




enemy1.bounceOff(edges)
enemy2.bounceOff(edges)
enemy3.bounceOff(edges)

if(keyDown(UP_ARROW)){
  hero.y=hero.y-8
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-8
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}
textSize(20)
  fill("blue")
  text("Goals:"+goal,320,350);
  

textSize(20)
  fill("blue")
  text("death:"+death,20,350);
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
